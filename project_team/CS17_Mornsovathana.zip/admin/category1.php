<?php include('includes/header.php')?>
<!-- start  -->
<div class = "h-full px-2 py-5 bg-blue-50">
<div class = "box-circle"> 
    <div class = "items-center justify-between inline w-full h-10 py-2 my-2 navbar-option">
        <div class = "box-option">
            <div class = "flex flex-col">
                <label for="">Product</label>
                <select name="product_item" id="product_item" class = "border-[1px] border-gray-200 outline-none">
                <option value = "" selected class = "text-[14px]">Select</option>
                <?php
                    $product = getAll("product_database");
                    if(mysqli_num_rows($product) > 0){
                        foreach($product as $productItem){
                            ?>
                            <option value="<?= $productItem['product_name']?>" class = "text-[14px]"><?= $productItem['product_name']?></option>
                            <?php
                        }
                    }
                ?>
                 </select>
            </div>
            <div class = "flex flex-col">
                <label for="">Categories</label>
                <select name="category_item" id="category_item" class = "text-md" class = "border-[1px] border-gray-200 outline-none">
                <option value = "" selected class = "text-[14px]">Select</option>
                <?php
                    $product = getAll("category_db");
                    if(mysqli_num_rows($product) > 0){
                        foreach($product as $productItem){
                            ?>
                            <option value="<?= $productItem['name']?>" class = "text-[14px]"><?= $productItem['name']?></option>
                            <?php
                        }
                    }
                ?>
                 </select>
            </div>
            <div class = "flex flex-col">
            <label for="">Brand</label>
                <select name="brand_item" id="brand_item" class = "border-[1px] border-gray-200 outline-none">
                <option value = "" selected class = "text-[14px]">Select</option>
                <?php
                    $product = getAll("product_database");
                    if(mysqli_num_rows($product) > 0){
                        foreach($product as $productItem){
                            ?>
                            <option value="<?= $productItem['product_name']?>" class = "text-[14px]"><?= $productItem['product_name']?></option>
                            <?php
                        }
                    }
                ?>
                 </select>
            </div>
            <div>
                <button class = "w-20 h-8 mr-2 text-sm text-white bg-blue-500 rounded-md shadow-sm" id = "filterData"><i class="fa-solid fa-filter"></i> Filter</button>
                <button class = "w-20 h-8 mr-2 text-sm text-white bg-blue-500 rounded-md shadow-sm"><i class="fa-solid fa-filter"></i> <a href="category.php">Add</a></button>
            </div>
        </div>
        <!-- <div class = "box-button ">
            <button id = "btn-product" class = "w-20 h-8 mr-2 text-sm text-white bg-blue-500 rounded-md shadow-sm"><i class="fa-solid fa-plus"></i>Add</button>
        </div> -->
    </div>
    <!-- end filter -->
    <div class = "container w-full my-5" id = "filter">
        <?php
            $category_pd = getAll("category_db");
            if(mysqli_num_rows($category_pd) > 0){
                foreach($category_pd as $category){
                ?>
                <div class = "p-2 px-1 rounded-sm shadow-md box h-[500px]" id = "category-<?= $category['id']?>">
                    <div class = "img">
                        <img src="../uploads/<?= $category['image']?>" alt="<?= $category['image']?>">
                    </div>
                    <div class = "text-sm title">
                        <div class = "flex items-center justify-between py-1">
                            <p><?= $category['product_id']?></p>
                            <p>$<?= $category['sell_price']?></p>
                        </div>
                        <p class = "text-center"><?= implode(' ', array_slice(explode(' ', $category['small_des']), 0, 5)) ?>...</p>
                        <div class = "option">
                            <i class="fa-solid fa-trash-can" id = "delete_category" data-category = "<?= $category['id']?>"></i>
                            <a href="categoryEdit.php?id=<?= $category['id']?>"><i class="fa-solid fa-pen-to-square btn-edit" ></i></a>
                        </div>
                    </div>
                </div>
                <?php
                }
            }
        ?>
        <!--  -->
    </div>
</div>
</div>
</div>
<!--  end  -->
<?php include('includes/footer.php')?>