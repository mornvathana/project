<?php include('includes/header.php')?>
<!--  -->
<div class = "h-full px-2 py-5 bg-blue-50">
            <div class = "box-ordering">
                <div class = "rounded-md shadow-md box-ordering-item">
                    <h3>Ordering</h3>
                    <h3>3</h3>
                </div>
                <div class = "rounded-md shadow-md box-ordering-item">
                    <h3>Order Success</h3>
                    <h3>3</h3>
                </div>
                <div class = "rounded-md shadow-md box-ordering-item">
                    <h3>Paid</h3>
                    <h3>3</h3>
                </div>
            </div>
            <!-- end ordering box -->
            <div class = "list-ordering">
                <div class = "shadow-md list-ordering-item">
                    <div class="list-header">
                        <span>Vathana</span>
                        <span class = "text-green-500"><i class="fa-solid fa-circle"></i></span>
                    </div>
                    <div class="list-header">
                        <span>Order</span>
                        <span>500</span>
                    </div>
                    <div class="list-header">
                        <span><i class="fa-regular fa-clock"></i></span>
                        <span style = "font-size: 12px;">12/1/2024 5:00 AM</span>
                    </div>
                    <div class = "list-body">   
                        <button>Verify</button>
                        <button>Check</button>
                        <button><i class="fa-solid fa-trash-can"></i></button>
                    </div>
                </div>
                <div class = "shadow-md list-ordering-item">
                    <div class="list-header">
                        <span>Vathana</span>
                        <span class = "text-green-500"><i class="fa-solid fa-circle"></i></span>
                    </div>
                    <div class="list-header">
                        <span>Order</span>
                        <span>500</span>
                    </div>
                    <div class="list-header">
                        <span><i class="fa-regular fa-clock"></i></span>
                        <span style = "font-size: 12px;">12/1/2024 5:00 AM</span>
                    </div>
                    <div class = "list-body">   
                        <button>Verify</button>
                        <button>Check</button>
                        <button><i class="fa-solid fa-trash-can"></i></button>
                    </div>
                </div>
                <div class = "shadow-md list-ordering-item">
                    <div class="list-header">
                        <span>Vathana</span>
                        <span class = "text-green-500"><i class="fa-solid fa-circle"></i></span>
                    </div>
                    <div class="list-header">
                        <span>Order</span>
                        <span>500</span>
                    </div>
                    <div class="list-header">
                        <span><i class="fa-regular fa-clock"></i></span>
                        <span style = "font-size: 12px;">12/1/2024 5:00 AM</span>
                    </div>
                    <div class = "list-body">   
                        <button>Verify</button>
                        <button>Check</button>
                        <button><i class="fa-solid fa-trash-can"></i></button>
                    </div>
                </div>
                <div class = "shadow-md list-ordering-item">
                    <div class="list-header">
                        <span>Vathana</span>
                        <span class = "text-green-500"><i class="fa-solid fa-circle"></i></span>
                    </div>
                    <div class="list-header">
                        <span>Order</span>
                        <span>500</span>
                    </div>
                    <div class="list-header">
                        <span><i class="fa-regular fa-clock"></i></span>
                        <span style = "font-size: 12px;">12/1/2024 5:00 AM</span>
                    </div>
                    <div class = "list-body">   
                        <button>Verify</button>
                        <button>Check</button>
                        <button><i class="fa-solid fa-trash-can"></i></button>
                    </div>
                </div>
                <div class = "shadow-md list-ordering-item">
                    <div class="list-header">
                        <span>Vathana</span>
                        <span class = "text-green-500"><i class="fa-solid fa-circle"></i></span>
                    </div>
                    <div class="list-header">
                        <span>Order</span>
                        <span>500</span>
                    </div>
                    <div class="list-header">
                        <span><i class="fa-regular fa-clock"></i></span>
                        <span style = "font-size: 12px;">12/1/2024 5:00 AM</span>
                    </div>
                    <div class = "list-body">   
                        <button>Verify</button>
                        <button>Check</button>
                        <button><i class="fa-solid fa-trash-can"></i></button>
                    </div>
                </div>
                <div class = "shadow-md list-ordering-item">
                    <div class="list-header">
                        <span>Vathana</span>
                        <span class = "text-green-500"><i class="fa-solid fa-circle"></i></span>
                    </div>
                    <div class="list-header">
                        <span>Order</span>
                        <span>500</span>
                    </div>
                    <div class="list-header">
                        <span><i class="fa-regular fa-clock"></i></span>
                        <span style = "font-size: 12px;">12/1/2024 5:00 AM</span>
                    </div>
                    <div class = "list-body">   
                        <button>Verify</button>
                        <button>Check</button>
                        <button><i class="fa-solid fa-trash-can"></i></button>
                    </div>
                </div>
            </div>
            
        </div>
<!--  -->
<?php include('includes/footer.php')?>