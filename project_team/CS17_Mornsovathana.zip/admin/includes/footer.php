
    <!--  -->
    <div class = "popup1">
        <div class = "frm1">
            <div class = "flex items-center justify-between w-full h-8 px-5 text-sm frm-header1 ">  
                <p>Product From</p>
                <i class="fa-solid fa-xmark"  id = "close-product1"></i>
            </div>
            <div class = "frm-body1">
                <div class = "img">
                    <img src="assets/img/download.png" alt="">
                </div>
                <div class = "frm-input1">
                    <label for="">Email</label>
                    <input type="text" placeholder = "Product Brand...">
                    <label for="">Password</label>
                    <input type="text" placeholder="Product Title...">
                    <label for="">Date</label>
                    <input type="date" placeholder="Product Price...">
                    <input type="button" class = "w-full text-white bg-blue-500" value = "save">
                </div>
            </div>
        </div>
    </div>

</body>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src= "assets/js/charts.js"></script>
<script src= "assets/js/custom.js"></script>
<script src= "assets/js/Data.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- toast message -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    <?php if (isset($_SESSION['message'])): ?>
        toastr.success("<?= $_SESSION['message'] ?>");
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    </script>
     <script>
    <?php if (isset($_SESSION['message1'])): ?>
        toastr.warning("<?= $_SESSION['message1'] ?>");
        <?php unset($_SESSION['message1']); ?>
    <?php endif; ?>
    </script>

</html>