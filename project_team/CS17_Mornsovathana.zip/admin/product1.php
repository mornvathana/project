<?php include('includes/header.php');?>
<!-- start -->
<div class = "h-full px-2 py-2 bg-blue-50">
           <div class = "box-circle">
            <div class = "box-item">
            <div class = "item-1">
                <p>Total Main Product</p>
                <?php
                $count = countTable("product_database");
                ?>
                <h1><?= $count ?></h1>
                <?php
                ?>
            </div>
            <div class = "item-1">
                <p>Total Sub Category</p>
                <?php
                $count = countTable("category_db");
                ?>
                <h1><?= $count ?></h1>
                <?php
                ?>
            </div>
            <div class = "item-1">
                <p>Total Brands</p>
                <h1>0</h1>
            </div>
            </div>
            <div class = "box-item1 mb-3">
                <div>
                    <form action="">
                    <input type="text" pattern="[A-Za-z\s]+" title="Only English letters are allowed" name = "product_name" class = "input-value py-2 outline-none border-[1px] border-gray-200 rounded-md" placeholder = "Product Name">
                    <button id = "btn-product">Add</button>
                    </form>
                </div>
            </div>
            <div class = "body-circle">
                <table class = "text-center">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product Name</th>
                            <th width = "400">Total Sub Category</th>
                            <th width = "160">Option</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                         $product_title = getAll("product_database");
                         if(mysqli_num_rows($product_title)){
                            foreach($product_title as $product){
                                ?>
                            <tr id = "product-<?= $product['id']?>">
                            <td><?= $product['id']?></td>
                            <td id = "productName"><?= $product['product_name']?></td>
                            <td><span id = "circle">
                                <?php
                                    $count = countCategoryItem("category_db",$product['product_name']);
                                    ?>
                                    <?= $count?>
                                    <?php
                                ?>
                            </span></td>
                            <td>
                                <button class = "bg-blue-500 btn_more" id = "productEdit" data-id = "<?= $product['id']?>">Edit</button>
                                <button class = "bg-blue-500 btn_more btn_delete" id = "btn-delete" data-id = "<?= $product['id']?>">Remove</button>
                            </td>
                            </tr>
                            <?php
                            }
                         }
                        ?>
                    </tbody>
                </table>
            </div>
           </div>
        </div>
<!-- end start -->
<?php include('includes/footer.php')?>