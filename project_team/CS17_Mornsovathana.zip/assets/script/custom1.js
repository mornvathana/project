$(document).ready(function(){
    $("#checkOut").click(function(){
        alert("Hello");
    });
});