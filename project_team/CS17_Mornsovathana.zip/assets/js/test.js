$(document).ready(function(){
    $("#test").click(function(){
        alert("Hello");
    });
});