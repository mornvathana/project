<?php
    $host = "smtp.gmail.com";
    $username = "mornsovathana@gmail.com";
    $sender = "me@example.com";
    $hostPassword = "adjujoekjgqfxeqg";
?>